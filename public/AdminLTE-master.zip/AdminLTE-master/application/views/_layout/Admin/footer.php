<footer class="main-footer">
    <strong><?= $ss_settings->footer_left ?></strong>

    <div class="float-right d-none d-sm-inline-block">
        <b><?= $ss_settings->footer_right ?></b>
</footer>