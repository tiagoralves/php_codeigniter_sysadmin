<script>
  $(document).ready(function() {
    $(".preloader").fadeOut();
  })
</script>
<section class="content">
  <div class="error-page mt-15">
    <h4 class="headline text-yellow"><i class="fa fa-2x fa-warning text-yellow"></i></h4>

    <div class="error-content">
      <h1>Maaf Halaman ini masih dalam tahap pengembangan.</h1>
    </div>
  </div>
</section>